# sealdice-builtins

这个仓库目前存储了海豹的内置牌堆与查询资料
